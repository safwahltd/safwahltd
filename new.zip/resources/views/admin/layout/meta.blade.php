<!-- META DATA -->
<meta charset="UTF-8">
<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="title" content="{{$company->meta_title}}">
<meta name="description" content="{{$company->meta_description}}">
<meta name="author" content="{{$company->meta_author}}">
<meta name="keywords" content="{{$company->meta_keyword}}">
