import './bootstrap';
required('select2');
